# Multi-Browser Automation (Playwright)

## Setup
```bash
git clone https://github.com/<your-username>/multi-browser
cd multi-browser
npm install
npx playwright install --with-deps
```

## Run
पहली बार: हर profile से manually login करो (cookies save हो जाएँगी)।  
```bash
npm run playall -- "https://youtube.com/watch?v=..."
```

## Config
- `config/profiles.json`: profiles add करो (100+ भी कर सकते हो)  
- `concurrency`: कितने profiles parallel में चलें  
- Profiles data `profiles/` folder में save होगा  
