import sw from "stopword";
import { compareTwoStrings } from "string-similarity";

const STOPWORDS = new Set(sw.en);

function tokenize(text) {
  return (text || "")
    .toLowerCase()
    .replace(/[#@]/g, " ")
    .replace(/[^\p{L}\p{N}\s]/gu, " ")
    .split(/\s+/)
    .filter(Boolean);
}

function keywordScores(text) {
  const tokens = tokenize(text).filter(t => !STOPWORDS.has(t) && t.length > 2);
  const freq = new Map();
  for (const t of tokens) freq.set(t, (freq.get(t) || 0) + 1);

  for (let i = 0; i < tokens.length - 1; i++) {
    const bigram = `${tokens[i]} ${tokens[i+1]}`;
    if (!bigram.split(" ").some(t => STOPWORDS.has(t))) {
      freq.set(bigram, (freq.get(bigram) || 0) + 1.5);
    }
  }
  return [...freq.entries()]
    .sort((a,b) => b[1] - a[1])
    .map(([k]) => k);
}

export function generateTags({ title, description }, { maxTags = 15 } = {}) {
  const candidates = keywordScores(`${title} ${description}`);
  const deduped = [];
  for (const c of candidates) {
    if (!deduped.some(d => compareTwoStrings(d, c) > 0.85)) deduped.push(c);
    if (deduped.length >= maxTags) break;
  }
  const hashtags = deduped
    .map(t => "#" + t.replace(/\s+/g, ""))
    .slice(0, maxTags);

  return { tags: deduped.slice(0, maxTags), hashtags };
}