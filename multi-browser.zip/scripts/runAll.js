import { chromium } from "playwright";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { extractMeta } from "./metadata.js";
import { generateTags } from "./tags.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const cfg = JSON.parse(fs.readFileSync(path.join(__dirname, "..", "config", "profiles.json"), "utf8"));

const profilesDir = path.join(__dirname, "..", "profiles");
if (!fs.existsSync(profilesDir)) fs.mkdirSync(profilesDir, { recursive: true });

function chunk(arr, size) {
  const out = [];
  for (let i = 0; i < arr.length; i += size) out.push(arr.slice(i, i + size));
  return out;
}

async function ensureContext(browser, name) {
  const dir = path.join(profilesDir, name);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  const context = await browser.newContext({
    viewport: { width: 1366, height: 768 },
    storageState: path.join(dir, "state.json")
  });
  context.on("close", async () => {
    try { await context.storageState({ path: path.join(dir, "state.json") }); } catch {}
  });
  return { context, dir };
}

async function openAndPlay(context, url) {
  const page = await context.newPage();
  await page.goto(url, { waitUntil: "domcontentloaded", timeout: 60000 });
  try {
    await page.evaluate(() => {
      const vids = Array.from(document.querySelectorAll("video"));
      vids.forEach(v => { v.muted = true; v.play().catch(()=>{}); });
      const btn = document.querySelector('button[aria-label*="Play" i], .ytp-play-button, [data-testid*="play" i]');
      btn && btn.click();
    });
  } catch {}
  return page;
}

async function run(url) {
  const browser = await chromium.launch({
    headless: false,
    args: [
      "--autoplay-policy=no-user-gesture-required",
      "--disable-features=PreloadMediaEngagementData,MediaEngagementBypassAutoplayPolicies"
    ]
  });

  const batches = cfg.openInBatches ? chunk(cfg.profiles, cfg.concurrency || 5) : [cfg.profiles];
  const results = [];

  for (const group of batches) {
    const opened = [];
    await Promise.all(group.map(async (p) => {
      const { context, dir } = await ensureContext(browser, p.name);
      const page = await openAndPlay(context, url);
      const meta = await extractMeta(page);
      const tags = generateTags(meta, { maxTags: 15 });
      results.push({ profile: p.name, meta, tags });
      opened.push({ context, dir });
    }));
    await new Promise(r => setTimeout(r, 1500));
    for (const o of opened) {
      try { await o.context.storageState({ path: path.join(o.dir, "state.json") }); } catch {}
      await o.context.close();
    }
  }

  await browser.close();
  return results;
}

const url = process.argv[2];
if (!url) {
  console.error("Usage: npm run playall -- <VIDEO_URL>");
  process.exit(1);
}

run(url).then((res) => {
  console.log(JSON.stringify(res, null, 2));
}).catch((e) => {
  console.error("Error:", e);
  process.exit(1);
});