export async function extractMeta(page) {
  const data = await page.evaluate(() => {
    const pick = (sel) => {
      const el = document.querySelector(sel);
      return el ? (el.content || el.innerText || el.textContent || "").trim() : "";
    };
    const best = (...vals) => vals.find(v => v && v.length > 0) || "";
    const title = best(
      pick('meta[property="og:title"]'),
      document.title,
      pick('meta[name="twitter:title"]')
    );
    const description = best(
      pick('meta[property="og:description"]'),
      pick('meta[name="description"]'),
      pick('meta[name="twitter:description"]')
    );
    return { title, description };
  });
  return data;
}